public class Variable {
    String varibleName;
    String type;

    public Variable(String varibleName, String type) {
        this.varibleName = varibleName;
        this.type = type;
    }

    @Override
    public String toString() {
        return type + " " + varibleName + ";";
    }
}
