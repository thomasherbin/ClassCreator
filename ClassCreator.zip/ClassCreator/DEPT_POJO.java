public class DEPT_POJO {
 private String DEPTNO ;
}
public class DEPT_POJO {
 private String DNAME ;
}
public class DEPT_POJO {
 private String LOC ;
}
